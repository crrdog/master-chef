2 1/4 cups all purpose flour
1 teaspoon baking soda
1/2 teaspoon salt
1 cup butter, softened
3/4 cup granulated sugar
3/4 cup packed brown sugar
1 egg
1 teaspoon vanilla essence
2 cups semisweet chocolate chips
