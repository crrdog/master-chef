Heat oven to 375 F. In a small bowl, mix the flour, baking soda and salt; set aside.

In a large bowl, beat softened butter and sugars with an electric mixer on medium speed, or mix with a spoon for about a minute or until fluffy, scraping side of bowl occasionally.

Beat in egg and vanilla until smooth. Stir in flour mixture just until blended (dough will be stiff). Stir in chocolate chips.

Onto ungreased cookie sheets, drop dough rounded tablespoonfuls 2 inches apart.

Bake 8 to 10 minutes or until light brown(centers will be soft). Cool 2 minutes; remove he cookes from the cookie sheet to a cooling rack. Cool completely, for about 30 minutes. 

AND your cookies are ready to eat.